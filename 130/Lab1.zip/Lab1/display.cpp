#include "display.h"
#include <iostream>

using namespace std;

void displayMenu() {
  cout << "\nClass Roster Menu:\n";
  cout << "1. Add Student\n";
  cout << "2. Drop Student\n";
  cout << "3. List Students (by last name)\n";
  cout << "4. List Students (by first name)\n";
  cout << "5. List Students (by ID)\n";
  // cout << "6. Update Student\n";
  cout << "7. Exit\n";
  cout << "Enter your choice: ";
}
