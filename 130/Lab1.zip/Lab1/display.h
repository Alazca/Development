#ifndef DISPLAY_HPP_
#define DISPLAY_HPP_
#include "student.h"

void displayMenu();

#endif
